# Diabetes-Prediction-WebApp-StreamLit


Link to my webApp: https://share.streamlit.io/tandrimasingha/diabetes-prediction-webapp-streamlit/main/diabetes_prediction_webapp.py
